# 大尾巴闪念

Android 本地闪念捕捉 App。第一版目标是打开即写、一键保存、时间流回看、搜索、Markdown 导出。

当前工程目录为 `DabaweiFlashNote`，沿用手工 Android SDK 构建链路，不依赖 Gradle 下载。

## 功能

- 打开 App 后自动聚焦闪念输入框。
- 点击“保存”后写入本地 SQLite，并立即刷新时间流。
- 历史记录按时间倒序显示。
- 搜索框实时筛选历史闪念。
- “导出 Markdown”会导出到应用外部文件目录的 `exports` 文件夹。

## 构建

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\build-apk.ps1
```

输出：

```text
build\outputs\DabaweiFlashNote-debug.apk
```

## 测试

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\test-hello.ps1
powershell -ExecutionPolicy Bypass -File .\tools\test-markdown-exporter.ps1
```

## 安装到真机

先确认 `adb devices` 里设备状态为 `device`，再执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\install-apk.ps1
```

当前项目暂时使用 Android SDK 工具链手工构建 APK，不依赖 Gradle 下载。这样可以先绕开 Gradle 分发包下载不稳定的问题，优先验证 Android SDK、签名和真机安装链路。

## 最近交接摘要

- 2026-06-06：从 Hello World 验证 App 改为“大尾巴闪念”MVP，新增 SQLite 本地保存、时间流、搜索、Markdown 导出。
- 2026-06-06：新增 `MarkdownExporter` 纯 Java 测试和资源 sanity 测试；构建脚本会在当前进程内补 `JAVA_HOME`、`ANDROID_HOME`、`ANDROID_SDK_ROOT` 和 Java `Path`，避免新 PowerShell/Codex 会话找不到 Java。
- 2026-06-06：工程目录改名为 `DabaweiFlashNote`，包名改为 `com.dabawei.flashnote`，APK 输出改为 `DabaweiFlashNote-debug.apk`。
- 2026-06-06：已通过资源测试、Markdown 导出测试、APK 构建、签名验证、vivo X200 Pro 真机安装和 adb 启动；旧测试包 `com.dabawei.helloworld` 已卸载。
- 2026-06-06：完成 UI v0.2，美化顶部标题区，新增纸张、夜墨、森绿三套主题，主题选择会写入 `SharedPreferences`；已重新安装并通过 adb 启动。
- 2026-06-06：完成桌面组件 v0.3，新增 2x1 快捷组件、最近一条闪念展示、点击组件打开快速输入页，保存后刷新组件；APK 版本为 `versionCode=3`、`versionName=0.3-widget`，已重新推送到 vivo X200 Pro。
- 2026-06-06：完成 WebDAV 锚点同步 v0.4，新增同步设置页、默认锚点 `<!-- DABAWEI_FLASHNOTE_INBOX -->`、WebDAV 下载/插入/上传和 ETag 冲突保护；APK 版本为 `versionCode=4`、`versionName=0.4-webdav`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 设备列表为空，尚未推送到手机。
- 2026-06-06：完成批量同步 v0.5，保存闪念只进入本地 pending 队列；在同步设置页点击“立即同步待同步”后，一次性同步所有 pending/failed 闪念。APK 版本为 `versionCode=5`、`versionName=0.5-batch-sync`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 设备列表为空，尚未推送到手机。
- 2026-06-06：完成坚果云默认配置 v0.6，同步设置页首次打开会自动带出坚果云 WebDAV 默认配置和目标 Markdown 路径；新增 `WebDavUrlBuilder` 处理反斜杠、空格和中文路径编码。APK 版本为 `versionCode=6`、`versionName=0.6-nutstore-defaults`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-06：完成设置页整理 v0.7，主界面顶部改为“同步”按钮 + 齿轮设置；主题切换、同步配置和 Markdown 导出集中到设置页；时间流卡片对已同步笔记显示“已同步”小标记。APK 版本为 `versionCode=7`、`versionName=0.7-settings-sync-badge`，已安装并通过 adb 启动。
- 2026-06-06：完成删除笔记 v0.8，时间流卡片新增“删除”按钮，删除后刷新本地列表和桌面组件；同步按钮保持绿色实心按钮造型。APK 版本为 `versionCode=8`、`versionName=0.8-delete-note`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-06：完成删除图标 v0.9，将时间流卡片文字“删除”改为垃圾桶 `ImageButton`，新增本地 vector 图标 `ic_trash`。APK 版本为 `versionCode=9`、`versionName=0.9-trash-icon`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 设备列表为空，尚未推送到手机。
- 2026-06-06：完成保存为待办 v0.10，主输入区保存按钮旁新增“保存为待办”；数据库新增 `note_type` 字段，WebDAV 批量同步时待办笔记写成 Obsidian 任务格式并追加 `#待办` 标签。APK 版本为 `versionCode=10`、`versionName=0.10-save-todo`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-06：完成待办标签 v0.11，时间流卡片中待办笔记显示商务蓝“待办”标签；同步到 Obsidian 仍写为 `- [ ] 时间 内容 #待办`。APK 版本为 `versionCode=11`、`versionName=0.11-todo-badge`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-06：完成纸面工作流标签 v0.12，卡片底部标签顺序调整为“待办”优先于“已同步”，待办为商务蓝实心标签，已同步为轻量绿色描边标签。APK 版本为 `versionCode=12`、`versionName=0.12-paper-badges`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-06：完成设计主题 v0.13，设置页主题循环新增 Apple、Linear、Notion、Raycast、Obsidian 五套风格；当前共 8 套主题：纸张、夜墨、森绿、Apple、Linear、Notion、Raycast、Obsidian。APK 版本为 `versionCode=13`、`versionName=0.13-design-themes`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-06：完成主题下拉与动作按钮主题化 v0.14，设置页主题切换改为 `Spinner` 下拉菜单；保存、保存为待办、同步分别读取主题内独立动作色。APK 版本为 `versionCode=14`、`versionName=0.14-theme-dropdown-buttons`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-07：完成同步标签后置 v0.16，普通笔记 WebDAV 同步写为 `- 时间 内容 #闪念`，待办笔记写为 `- [ ] 时间 内容 #闪念 #待办`。APK 版本为 `versionCode=16`、`versionName=0.16-sync-tags-after-content`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-08：完成纸张主题 UI 重绘与记录操作菜单 v0.17，第一套“纸张”主题改为白底、墨黑大标题、深绿动作按钮、轻阴影输入框和时间线卡片；点击记录弹出编辑、重新同步、切换待办/普通笔记、删除菜单，删除增加确认。APK 版本为 `versionCode=17`、`versionName=0.17-paper-ui-note-actions`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-08：完成纸张主题现代视觉重构 v0.18，顶栏改为左侧标题/状态和右侧 `+ 记录闪念`，搜索框改为放大镜容器，输入框增加图片/语音/# 工具栏，操作按钮、时间流卡片、透明删除图标和底部四 Tab 导航按纸张主题精修。APK 版本为 `versionCode=18`、`versionName=0.18-paper-ui-polish`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-08：完成纸张主题阴影与标签修正 v0.19，移除搜索框、输入框、按钮、卡片和底部导航的动态阴影；顶栏按钮改为“同步笔记”并恢复同步动作；待办/已同步标签改为无描边浅色胶囊，提高对比度。APK 版本为 `versionCode=19`、`versionName=0.19-paper-shadow-badge-fix`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-08：完成纸张主题按钮细修 v0.20，顶部“同步笔记”按钮缩小为 44dp 高度并减少最小宽度；输入框右下图片/语音/# 工具栏已移除；按钮默认 `stateListAnimator` 关闭以彻底去除残留阴影。APK 版本为 `versionCode=20`、`versionName=0.20-paper-button-cleanup`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-08：完成输入辅助按钮 v0.21，在闪念输入框下新增“上传图片”和“剪切板”；上传图片使用系统图片选择器并插入 `![图片](uri)`，剪切板读取最近一条文本并填入输入框。APK 版本为 `versionCode=21`、`versionName=0.21-input-assist-buttons`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-08：完成 UI 图标重绘 v0.22，将 `icon\小荳` 下 SVG 批量转换为 Android vector drawable；上传图片/剪切板作为输入框内部右下角 `ImageButton`，保存、保存为待办、同步笔记、底部导航、删除等入口统一替换为对应图标。APK 版本为 `versionCode=22`、`versionName=0.22-icon-redraw-input-toolbar`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-08：修复 v0.22 启动崩溃，根因是 SVG 转 Android vector 时正则误捕获 `p-id` 为 `pathData`，造成 `ic_input_image` 无法 inflate；已重生成全部小荳图标 vector，并用 adb 重新安装、启动验证，未再发现启动崩溃。
- 2026-06-08：完成纸张主题密度清理 v0.23，收窄“同步笔记”、保存、保存为待办按钮高度；保存文案改为“保存单条笔记”；已同步状态去掉文字前小圆点，时间流右侧“全部”去掉；底部导航去除图标，仅保留文字。APK 版本为 `versionCode=23`、`versionName=0.23-paper-density-cleanup`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-08：完成底部导航图标修复 v0.24，底部四个入口按指定 SVG 恢复为 `1-首页.svg`、`2-历史.svg`、`3-统计.svg`、`4-设置.svg`，文字改为“首页、历史、统计、设置”；重新生成安全 Android vector 并增加非法 `pathData` 自查。APK 版本为 `versionCode=24`、`versionName=0.24-bottom-nav-icons`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装和 adb 启动。
- 2026-06-08：完成底部导航对齐修复 v0.25，底部四个 Tab 改为独立 `ImageView + TextView` 垂直布局，图标放大到 26dp，修正图标不居中和过小的问题。APK 版本为 `versionCode=25`、`versionName=0.25-bottom-nav-align`。已通过资源测试、纯 Java 测试、APK 构建、签名验证、vivo X200 Pro 安装、adb 启动和真机截图复核。
- 2026-06-11：完成 Obsidian 写入格式优化 v0.26，WebDAV 同步写入从单行列表改为结构化闪念块：`#### 闪念-yyyyMMddHHmm`、闪念/待办列表项、`记录日期::`、`备注::`、`^flash-yyyyMMdd-HHmm`；待办格式为 `- [ ] 内容 #闪念 #待办`，普通格式为 `- 内容 #闪念`。APK 版本为 `versionCode=26`、`versionName=0.26-obsidian-flash-blocks`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-11：完成 Obsidian 闪念标题格式微调 v0.27，WebDAV 同步写入标题从 `#### 闪念-yyyyMMddHHmm` 改为 `**闪念-yyyyMMddHHmm**`，其他结构化字段保持不变。APK 版本为 `versionCode=27`、`versionName=0.27-obsidian-bold-flash-title`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-11：完成 Obsidian 闪念标题前缀微调 v0.28，WebDAV 同步写入标题从 `**闪念-yyyyMMddHHmm**` 改为 `**大尾巴闪念-yyyyMMddHHmm**`，其他结构化字段保持不变。APK 版本为 `versionCode=28`、`versionName=0.28-dawei-flash-title`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-11：完成纸张主题按钮与顶部 Logo 优化 v0.29，保存/保存为待办按钮改为柔和浅色块，纸张主题使用 `#F0F7F4` / `#EEF6F2` 浅底和 `#2D5A47` 文字图标，其他主题同步补充独立动作色；顶部 Logo 增加字距、改用 `sans-serif-medium`，并按系统状态栏高度动态补顶部安全区。APK 版本为 `versionCode=29`、`versionName=0.29-soft-actions-logo-safearea`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-11：完成 Obsidian 图片附件上传 v0.30，输入框上传图片按钮会把手机图片通过 WebDAV 上传到目标 Markdown 同级 vault 的 `assets` 目录，默认路径对应 `OBS/Damon/assets`；上传成功后插入 `![[assets/文件名|200]]`，使 Obsidian 以 200 像素宽度展示图片。APK 版本为 `versionCode=30`、`versionName=0.30-obsidian-image-assets`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-11：完成图片延迟上传 v0.31，选择图片时只在输入框插入 `![待上传图片](content://...)` 占位，可继续输入文字并保存进本地数据库；同步笔记或重新同步单条时，再上传占位图片到目标 vault 的 `assets` 目录并替换为 `![[assets/文件名|200]]`。APK 版本为 `versionCode=31`、`versionName=0.31-deferred-image-upload`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-11：修复图片同步失败 v0.32，移除 Android `HttpURLConnection` 不支持的 `MKCOL` 请求，图片上传改为直接 `PUT` 到已存在的 `OBS/Damon/assets`，避免 `Expected one of [OPTIONS, GET, HEAD, POST, PUT...]` 报错；若 assets 目录不存在，会提示先创建目录。APK 版本为 `versionCode=32`、`versionName=0.32-image-put-no-mkcol`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-11：完成设置页版本信息 v0.33，设置页底部显示 `versionName/versionCode` 和构建日期；构建脚本每次打包前生成 `BuildInfo.java` 保存当前构建时间。APK 版本为 `versionCode=33`、`versionName=0.33-settings-version-info`，本次构建日期为 `2026-06-11 11:56`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-12：修复同步目标 Markdown 404 v0.34，默认同步路径更新为 `OBS\Damon\【MOC】闪念-随手记.md`，并自动迁移旧默认路径 `OBS\Damon\【MOC】随手记-Claw编辑版.md`；已用 WebDAV 验证新路径 HTTP 200。APK 版本为 `versionCode=34`、`versionName=0.34-sync-path-flash-note`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；安装时 adb 连接中断，尚未成功推送到手机。
- 2026-06-12：完成输入框下拉快捷动作 v0.35，输入框区域下拉会带动整页下移并露出隐藏同步图标，松手超过阈值后震动一次；输入框有内容则保存普通单条笔记，输入框为空则触发同步。APK 版本为 `versionCode=35`、`versionName=0.35-pull-input-save-sync`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-12：补充 APK 归档规则，`tools\build-apk.ps1` 每次构建前自动保存上一版本 APK 到 `apk-archive\` 并带版本号命名，成功构建后写入 `apk-archive\last-build.json`；已验证归档 `DabaweiFlashNote-v35-0.35-pull-input-save-sync.apk`。
- 2026-06-12：完成输入提示与下拉图标位置优化 v0.36，输入框提示改为“想到什么,马上写下，下拉保存，再拉同步”；下拉隐藏同步图标放大并下移，避开灵动岛/状态栏。APK 版本为 `versionCode=36`、`versionName=0.36-pull-hint-indicator`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-12：完成下拉图标完整露出与动作提示 v0.37，下拉隐藏指示改为“同步图标 + 提示语”横向组合；输入框有内容时提示“再拉就保存辣！”，输入框为空时提示“再拉就同步辣！”，并提高下拉最大距离保证整组提示完整露出。APK 版本为 `versionCode=37`、`versionName=0.37-pull-prompt-indicator`；构建前已自动归档上一版 `DabaweiFlashNote-v36-0.36-pull-hint-indicator.apk`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-12：完成输入框双行浅色提示 v0.38，输入框 hint 改为两行“想到什么 马上写下 / 下拉保存 再拉同步”，并将输入框提示色调浅，降低视觉存在感。APK 版本为 `versionCode=38`、`versionName=0.38-two-line-input-hint`；构建前已自动归档上一版 `DabaweiFlashNote-v37-0.37-pull-prompt-indicator.apk`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-12：完成下拉保存自动识别待办 v0.39，输入框下拉触发保存时会自动检测内容是否包含“待办”；包含则保存为待办笔记，不包含则保存为普通笔记，空输入框仍触发同步笔记。APK 版本为 `versionCode=39`、`versionName=0.39-pull-auto-todo`；构建前已自动归档上一版 `DabaweiFlashNote-v38-0.38-two-line-input-hint.apk`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-13：完成 Claude 字体风格设置 v0.40，设置页新增“Claude 字体风格”开关，可在现有主题之上切换为更接近 Claude 阅读气质的系统 serif 字体；主界面、时间流卡片、快速输入页和设置页会读取该开关。APK 版本为 `versionCode=40`、`versionName=0.40-claude-font-style`；构建前已自动归档上一版 `DabaweiFlashNote-v39-0.39-pull-auto-todo.apk`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-13：完成历史页和待办页入口骨架 v0.41，首页移除搜索框，底部“历史”页承接搜索栏和同款时间流列表，并支持历史页下拉同步；底部“统计”改为“待办”，待办页先显示“同步待办”入口和空状态，占位等待下一版接入 Obsidian 待办拉取。APK 版本为 `versionCode=41`、`versionName=0.41-history-todo-skeleton`；构建前已自动归档上一版 `DabaweiFlashNote-v40-0.40-claude-font-style.apk`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-13：修复历史页翻阅冲突 v0.42，移除历史页搜索栏、标题和时间流列表上的下拉同步监听；下拉保存/同步仅保留在首页输入框区域，避免影响历史页正常滚动翻阅。APK 版本为 `versionCode=42`、`versionName=0.42-history-scroll-fix`；构建前已自动归档上一版 `DabaweiFlashNote-v41-0.41-history-todo-skeleton.apk`。已通过资源测试、纯 Java 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-13：完成待办单一同步文件读取 v0.43，使用 Obsidian CLI 创建 `【MOC】大尾巴待办同步.md`，文件内包含 Tasks 查询区和 `DABAWEI_TODO_SYNC_BEGIN/END` 机器可读区块；App 待办页“同步待办”按钮通过坚果云 WebDAV 读取 `OBS\Damon\【MOC】大尾巴待办同步.md`，解析并显示待办正文、来源文件、行号和备注，不扫描整个 vault、不回写原始任务。APK 版本为 `versionCode=43`、`versionName=0.43-todo-sync-read`；构建前已自动归档上一版 `DabaweiFlashNote-v42-0.42-history-scroll-fix.apk`。已通过资源测试、纯 Java 测试、TodoSyncParser 测试、WebDAV GET 200 验证、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-13：完成 Obsidian 端待办同步插件 v1.0.0，安装到 `C:\OBS\Damon\.obsidian\plugins\dabawei-todo-sync` 并加入启用列表；插件命令为“刷新大尾巴待办同步文件”，会扫描 vault 中未完成且包含 `#待办` 的任务，按既定排除文件/目录规则写入 `【MOC】大尾巴待办同步.md` 的 `DABAWEI_TODO_SYNC_BEGIN/END` 区块。已通过 Node 纯函数测试、Obsidian 插件 reload、命令执行、`dev:errors` 无错误和坚果云 WebDAV GET 200 验证。
- 2026-06-17：优化 Obsidian 待办同步插件输出格式，同步区块内改为按来源笔记分组，使用 `### [[来源笔记]]` 标题分隔各笔记下的待办；任务行和 `来源文件::/行号::/块ID::/备注::` 元数据保持不变，手机端解析兼容。已通过 Node 纯函数测试、Obsidian 插件 reload、命令执行刷新和 `dev:errors` 无错误验证。
- 2026-06-17：完成手机端待办页分组与自动同步 v0.44，进入待办页时自动同步一次并移除占空间的“同步待办”按钮；待办列表按来源笔记分组显示，组标题展示笔记名/路径，组内卡片仅展示任务正文、行号和备注，减少重复信息。APK 版本为 `versionCode=44`、`versionName=0.44-todo-grouped-auto-sync`；构建前已自动归档上一版 `DabaweiFlashNote-v43-0.43-todo-sync-read.apk`。已通过资源测试、纯 Java 测试、TodoSyncParser 测试、APK 构建和签名验证；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-17：完成系统分享入口 v0.45，`大尾巴闪念` 会出现在其他 App 的分享列表中；分享文字和链接会自动填入首页输入框，分享单张或多张图片会插入 `![待上传图片](content://...)` 占位，保存后继续沿用延迟上传到 Obsidian `assets` 的链路。APK 版本为 `versionCode=45`、`versionName=0.45-share-target`；构建前已自动归档上一版 `DabaweiFlashNote-v44-0.44-todo-grouped-auto-sync.apk`。已通过资源测试、纯 Java 测试、APK 构建签名验证和 APK Manifest 反查；当前 adb 未发现设备，尚未推送到手机。
- 2026-06-17：修复分享图片同步权限丢失 v0.46，分享图片填入输入框时会先复制到 App 私有 `pending-images` 待上传目录，并以 `file://` 占位保存；同步图片时同时支持 `content://` 和 `file://` 占位，上传成功后自动删除本地待上传副本，避免 `has no access` 导致同步失败。APK 版本为 `versionCode=46`、`versionName=0.46-share-image-cache`。
- 2026-06-17：补充旧分享图片权限兜底 v0.47，若待同步旧记录里仍包含 `content://media/...` 图片占位，会在同步前请求系统图片读取权限，授权后自动继续同步；若拒绝授权则提示重新分享或重新选择图片。APK 版本为 `versionCode=47`、`versionName=0.47-legacy-media-permission`。同时调整版本备份策略：新增 `tools\backup-core-code.py`，构建前自动备份核心代码到 `90-版本代码备份\DabaweiFlashNote-版本号-日期.zip`，不再备份 APK。
